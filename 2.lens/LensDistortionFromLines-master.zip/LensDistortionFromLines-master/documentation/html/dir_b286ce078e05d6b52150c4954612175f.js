var dir_b286ce078e05d6b52150c4954612175f =
[
    [ "image_primitives.h", "image__primitives_8h.html", "image__primitives_8h" ],
    [ "line.h", "line_8h.html", "line_8h" ],
    [ "line_extraction.cpp", "line__extraction_8cpp_source.html", null ],
    [ "line_extraction.h", "line__extraction_8h_source.html", null ],
    [ "line_points.cpp", "line__points_8cpp.html", "line__points_8cpp" ],
    [ "line_points.h", "line__points_8h.html", "line__points_8h" ],
    [ "point2d.h", "point2d_8h.html", "point2d_8h" ],
    [ "subpixel_image_contours.cpp", "subpixel__image__contours_8cpp.html", "subpixel__image__contours_8cpp" ],
    [ "subpixel_image_contours.h", "subpixel__image__contours_8h.html", "subpixel__image__contours_8h" ]
];