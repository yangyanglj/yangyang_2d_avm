var searchData=
[
  ['point2d',['point2d',['../classami_1_1point2d.html',1,'ami']]],
  ['point2d_2eh',['point2d.h',['../point2d_8h.html',1,'']]],
  ['point2d_3c_20double_20_3e',['point2d&lt; double &gt;',['../classami_1_1point2d.html',1,'ami']]],
  ['points_5fto_5fequation',['points_to_equation',['../classami_1_1line__points.html#ad9f1f885954ce4f96fa1741cfbdc0427',1,'ami::line_points']]],
  ['projected_5f3dpoints',['projected_3dpoints',['../classami_1_1image__primitives.html#aadd919e1b7306926000739b72d8d2406',1,'ami::image_primitives']]]
];
