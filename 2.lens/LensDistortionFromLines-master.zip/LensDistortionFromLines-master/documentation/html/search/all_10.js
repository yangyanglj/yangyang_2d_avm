var searchData=
[
  ['y',['y',['../classami_1_1point2d.html#a9baf43c37e167ce9d90e0e623e9070e1',1,'ami::point2d']]]
];
