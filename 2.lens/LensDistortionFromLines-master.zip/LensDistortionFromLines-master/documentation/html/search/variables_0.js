var searchData=
[
  ['projected_5f3dpoints',['projected_3dpoints',['../classami_1_1image__primitives.html#aadd919e1b7306926000739b72d8d2406',1,'ami::image_primitives']]]
];
