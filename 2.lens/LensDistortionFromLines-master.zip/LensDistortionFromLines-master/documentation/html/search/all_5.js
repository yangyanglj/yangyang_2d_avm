var searchData=
[
  ['evaluation',['evaluation',['../classami_1_1lens__distortion__model.html#a469de0e5e24be6a07d40932873e0d029',1,'ami::lens_distortion_model::evaluation(const point2d&lt; double &gt; &amp;p) const '],['../classami_1_1lens__distortion__model.html#a6423ccf91de7b75b5a5b1e59af09f789',1,'ami::lens_distortion_model::evaluation(point2d&lt; double &gt; &amp;p)'],['../classami_1_1line.html#a28b4985152d84c31e2070a78477a9b80',1,'ami::line::evaluation()'],['../classami_1_1line__points.html#a9f30a3eef7bed813b0c85f5665323e51',1,'ami::line_points::evaluation()']]],
  ['evaluation_5fquotient',['evaluation_quotient',['../classami_1_1lens__distortion__model.html#a3a4e643804a7f7f5ed55a4ba3fcad5cd',1,'ami::lens_distortion_model::evaluation_quotient(const point2d&lt; double &gt; &amp;p) const '],['../classami_1_1lens__distortion__model.html#ae315b601e764d4e8a80ec1e15d9beeef',1,'ami::lens_distortion_model::evaluation_quotient(point2d&lt; double &gt; &amp;p)']]]
];
