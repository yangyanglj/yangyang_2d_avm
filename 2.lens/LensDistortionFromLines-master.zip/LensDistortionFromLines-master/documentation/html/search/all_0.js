var searchData=
[
  ['_5fio_5fpng_5ferr_5fs',['_io_png_err_s',['../struct__io__png__err__s.html',1,'']]]
];
