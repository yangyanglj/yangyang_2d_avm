var searchData=
[
  ['read',['read',['../classami_1_1image.html#a26370abafef955b1129eeb15103e65f5',1,'ami::image::read()'],['../classami_1_1lens__distortion__model.html#a29e576a12b99e392405846757d59b98f',1,'ami::lens_distortion_model::read()']]],
  ['reset',['reset',['../classami_1_1lens__distortion__model.html#a4b66415a706f5c0e028e39ed3fd09c9a',1,'ami::lens_distortion_model']]],
  ['resize',['resize',['../classami_1_1image.html#a42447010fa2c6e93086db8de0c9c0c05',1,'ami::image']]],
  ['rgb_5fto_5fhsv',['rgb_to_hsv',['../classami_1_1image.html#a1de87be46608336f7d9ea55d87ba5811',1,'ami::image']]]
];
