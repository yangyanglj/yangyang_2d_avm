var searchData=
[
  ['operator_28_29',['operator()',['../classami_1_1image.html#abb9cd9e3ce12f9d8da4d264814332526',1,'ami::image']]],
  ['operator_3d',['operator=',['../classami_1_1image.html#a00f573022bd8e69a5c61f3372a8d35d2',1,'ami::image']]],
  ['operator_5b_5d',['operator[]',['../classami_1_1image.html#af71991fe782d4fea2939379ad6dc4ad1',1,'ami::image::operator[](const int &amp;i)'],['../classami_1_1image.html#ad9334b5dfa67389de92020764326b56c',1,'ami::image::operator[](const int &amp;i) const ']]]
];
