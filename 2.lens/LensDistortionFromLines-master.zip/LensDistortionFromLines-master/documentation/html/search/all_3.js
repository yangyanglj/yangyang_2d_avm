var searchData=
[
  ['canny',['canny',['../filters_8h.html#a03cc9f11aeaf893008bf8713d37a1325',1,'canny(ami::image&lt; T &gt; input, ami::image&lt; T &gt; &amp;output, float *seno, float *coseno, int *x, int *y, float per_low, float per_high):&#160;filters.h'],['../filters_8h.html#a440b593d3c08771234e00d2d1299440f',1,'canny(ami::image&lt; T &gt; input, ami::image&lt; T &gt; &amp;edges, float canny_low_threshold, float canny_high_threshold):&#160;filters.h']]],
  ['clean',['clean',['../classami_1_1subpixel__image__contours.html#ac1072680e4a337a07a3c7acf90c8e34f',1,'ami::subpixel_image_contours']]],
  ['clear',['clear',['../classami_1_1image.html#aaa344b24143551df56dcb86e345ce9f4',1,'ami::image']]]
];
