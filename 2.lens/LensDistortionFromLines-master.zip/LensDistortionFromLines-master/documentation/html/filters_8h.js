var filters_8h =
[
    [ "filters_H", "filters_8h.html#acbccfea7ec5881173c3ec5f35a415898", null ],
    [ "ami_median_float", "filters_8h.html#aa8e304eb1057044fe7bfff1ba9ced80f", null ],
    [ "canny", "filters_8h.html#a03cc9f11aeaf893008bf8713d37a1325", null ],
    [ "canny", "filters_8h.html#a440b593d3c08771234e00d2d1299440f", null ],
    [ "gauss_conv", "filters_8h.html#a4899020779ab45f62d29161cfa6e35bf", null ],
    [ "grad", "filters_8h.html#adf7f58cebfbff0496de30b7867b344a6", null ]
];