var image__primitives_8h =
[
    [ "image_primitives", "classami_1_1image__primitives.html", "classami_1_1image__primitives" ],
    [ "IMAGE_PRIMITIVES_H", "image__primitives_8h.html#a6ebbc229e11ad00ba58380ffb3b292a8", null ]
];