一份简单的车辆环视系统制作教程，具体解释见[这里](http://pywonderland.com/post/vehicle-surround-view-system.html)。
