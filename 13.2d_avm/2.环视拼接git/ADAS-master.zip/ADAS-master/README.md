# ADAS
Automatic Driver Assistance System
Give the path to the video in the main.cpp file and run it.
These are sample results generated
Moving vehicles are detected in red bounding boxes
![Alt text](results/movobj.png?raw=true "Moving vehicles detected in 4 views highlighted in red color box")
Static vehicles are detected in yellow bounding boxes
![Alt text](results/statobj.png?raw=true "Moving vehicles detected in 4 views highlighted in red color box")
